package tn.sesame.pdlpdl.model.enums;

public enum ResultatMaintenance {
    SUCCES,
    ECHEC,
    EN_COURS,
    REPORTE
}