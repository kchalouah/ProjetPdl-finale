package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Ordonnance;

public interface IOrdonnanceService extends IService<Ordonnance, Long> {
    // Méthodes spécifiques à Ordonnance à ajouter ici
}