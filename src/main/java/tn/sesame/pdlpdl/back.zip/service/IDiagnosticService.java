package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Diagnostic;

public interface IDiagnosticService extends IService<Diagnostic, Long> {
    // Méthodes spécifiques à Diagnostic à ajouter ici
}