package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Administrateur;

public interface IAdministrateurService extends IService<Administrateur, Long> {
    // Méthodes spécifiques à Administrateur à ajouter ici
}