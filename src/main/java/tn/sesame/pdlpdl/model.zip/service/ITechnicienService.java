package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Technicien;

public interface ITechnicienService extends IService<Technicien, Long> {
    // Méthodes spécifiques à Technicien à ajouter ici
}