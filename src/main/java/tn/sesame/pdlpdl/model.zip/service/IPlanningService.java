package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Planning;

public interface IPlanningService extends IService<Planning, Long> {
    // Méthodes spécifiques à Planning à ajouter ici
}