package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Infirmier;

public interface IInfirmierService extends IService<Infirmier, Long> {
    // Méthodes spécifiques à Infirmier à ajouter ici
}