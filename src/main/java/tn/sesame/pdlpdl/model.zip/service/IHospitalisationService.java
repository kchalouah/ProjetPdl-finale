package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Hospitalisation;

public interface IHospitalisationService extends IService<Hospitalisation, Long> {
    // Méthodes spécifiques à Hospitalisation à ajouter ici
}