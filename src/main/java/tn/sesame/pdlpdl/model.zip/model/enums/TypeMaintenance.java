package tn.sesame.pdlpdl.model.enums;

public enum TypeMaintenance {
    PREVENTIVE,
    CORRECTIVE,
    CALIBRATION,
    INSTALLATION,
    MISE_A_JOUR
}