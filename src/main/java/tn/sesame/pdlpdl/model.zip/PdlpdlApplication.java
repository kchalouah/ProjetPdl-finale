package tn.sesame.pdlpdl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdlpdlApplication {

    public static void main(String[] args) {
        SpringApplication.run(PdlpdlApplication.class, args);
    }

}
