package tn.sesame.pdlpdl.service;

import tn.sesame.pdlpdl.model.entities.Patient;

public interface IPatientService extends IService<Patient, Long> {
    // Méthodes spécifiques à Patient à ajouter ici
}